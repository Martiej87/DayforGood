# DayForGood MVP
This is the MVP website for DayForGood — where anyone can donate a workday's worth of pay to a charity of their choice.

## Features
- Donation form (charity + workday date)
- Stripe Checkout integration
- Logs donations to `donations.json`
- Simple admin dashboard at `/admin.html`
